import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { RequestService } from '../../../services/request.service';

@Component({
  selector: 'wish-list',
  templateUrl: './wish-list.component.html'
})
export class WishListComponent implements OnInit {
  totalItemsInWishList:number;
  wishListItems: any;

  constructor(private _commonService: CommonService, private _requestService: RequestService) { }

  ngOnInit() {
    this.getUserWishList();
  }

  getUserWishList(){
    this._requestService.fetchAuthData("cart/getUserWishList").subscribe(
      data=>{
        const dataItem=data.json();
        if(dataItem.status=="OK"){
          this.wishListItems=dataItem.response;
          this.totalItemsInWishList=this.wishListItems.length;
        }
        else{
          this._commonService.showHttpErrorMsg();
        }
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
  }

  openDetails(listItem){}

  moveToCart(itemId,price,index){
    this._requestService.fetchAuthData("cart/moveItemToCart?item="+itemId+"&price="+price).subscribe(
      data=>{
        if(data.json().status=="OK"){
          this._commonService.showAlert({
            type: "success", msg: data.json().response
          });
          this.updateWishList(index);
        }
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
  }

  private updateWishList(index){
     this.wishListItems.splice(index,1);
  }

}
