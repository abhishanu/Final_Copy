import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { RequestService } from '../../services/request.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html'
})
export class CartComponent implements OnInit {
   cartItemsList: any;
   totalItemsInCart:number;
   itemAmt:number;
   totalCartAmt:number;
   gst:number;
   deliveryDetails:any;
   userName:any;
   constructor(private router:Router,private _commonService: CommonService, private _requestService: RequestService) {
    this.gst=this._commonService.donationGst;
  }

  ngOnInit() {
    this.userName=this._commonService.userName;
    if (this._commonService.checkAlreadyLoggedIn()) {
      this._commonService.updateBreadCrumb([]);
      this.getUserDeliveryDetails();
      this.getUserCart();
    }
    else{
      this._commonService.redirectToLogin();
    }
  }

  amtChanged(event,itemId,lastAmt){
    let keycode = event.keycode || event.which;

    if (keycode == 13) {
      if(event.target.value!=lastAmt){
     
        this._requestService.fetchAuthData("cart/changeDonationAmt?item="+itemId+"&amt="+event.target.value).subscribe(
          data=>{
            const dataItem=data.json();
            if(dataItem.status=="OK"){
              this._commonService.showAlert({
                type: "success", msg: data.json().response
              });
              this.getUserCart();
            }
          },
          err=>{
            this._commonService.showHttpErrorMsg();
          }
        );
      } 
    }
  }

  removeCartItem(itemId,index){
    this._requestService.fetchAuthData("cart/removeCartItem/"+itemId).subscribe(
      data=>{
        if(data.json().status=="OK"){
          this._commonService.showAlert({
            type: "success", msg: data.json().response
          });
          this.updateCart(index);
        }
        
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
  }

  totalCartAmmount(cartDetails){
    this.totalCartAmt=0;
    cartDetails.forEach(data => {
      this.totalCartAmt+=data.Price;
    });
  }

  moveToWishList(itemId,price,index){
    this._requestService.fetchAuthData("cart/moveItemToWishList?item="+itemId+"&price="+price).subscribe(
      data=>{
        if(data.json().status=="OK"){
          this._commonService.showAlert({
            type: "success", msg: data.json().response
          });
          this.updateCart(index);
        }
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
  }

  refresh(){setTimeout(()=>{
    //window.location.reload();
  },2000);
    
  }

  openDetails(cartItem){
    if(cartItem.IsTemple){
      
    }
    if(cartItem.IsPandit){

    }
    if(cartItem.IsPooja){

    }
  }

  getUserCart(){
    this._requestService.fetchAuthData("cart/getUserCart").subscribe(
      data=>{
        const dataItem=data.json();
        if(dataItem.status=="OK"){
          this.cartItemsList=dataItem.response;
          this.totalItemsInCart=this.cartItemsList.length;
          this.totalCartAmmount(this.cartItemsList);
        }
        else{
          this._commonService.showHttpErrorMsg();
        }
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
  }
  
  getUserDeliveryDetails(){
    this._requestService.fetchAuthData("getUserDeliveryAddress").subscribe(
      data=>{
        const dataItem=data.json();
        if(dataItem.status=="OK"){
          this.deliveryDetails=dataItem.response;
        }
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
  }

  payCart(){
    
  }
  private updateCart(index){
    this.totalCartAmt-=this.cartItemsList[index].Price;
    this.cartItemsList.splice(index,1);
    this.totalItemsInCart=this.cartItemsList.length;
  }

  addNewAddress(){
    this.router.navigate(['my']);
  }
}
