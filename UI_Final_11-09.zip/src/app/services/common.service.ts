//Application level services 
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import {tokenNotExpired} from 'angular2-jwt';
import { Router } from '@angular/router';

@Injectable()
export class CommonService {
  private showModalHandler = new Subject<any>();
  showModal$ = this.showModalHandler.asObservable();
  public dashbordTab:any;
  public dashbordSubCatTab:any;
  private showLoaderHandler = new Subject<any>();
  showLoader$ = this.showLoaderHandler.asObservable();
  currentCity:any="Delhi";
 
  private hideLoaderHandler = new Subject<any>();
  hideLoader$ = this.hideLoaderHandler.asObservable();

  public showAlertHandler = new Subject<any>();
  public breadCrumbHandler = new Subject<any>();
  public ordersHandler = new Subject<any>();
  public creditHandler = new Subject<any>();
  public wishlistHandler = new Subject<any>();
  public accountHandler = new Subject<any>();
  public mapOverlayHandler = new Subject<any>();
  public loginHandler = new Subject<any>();
  public completeCitilist:any=[];
  public allStates:Array<any>=new Array();
  public userName="MY ACCOUNT";
  public userDetails:any=[];

  public donationGst:number=5;
  constructor(private router: Router) { }
  showModal(option) {
    this.showModalHandler.next(option);
  }
  showLoader() {
    this.showLoaderHandler.next();
  }
  hideLoader() {
    this.hideLoaderHandler.next();
  }
  showAlert(option) {
    this.showAlertHandler.next(option);
  }
  dashboardUpdate(option){
    if(option.type =='orders'){
      this.ordersHandler.next(option);
    }
    
    else if(option.type =='credit'){
      this.creditHandler.next(option);
    }
    
   else if(option.type =='wishlist'){
      this.wishlistHandler.next(option);
    }
    
    else {
      this.accountHandler.next(option);
      this.dashbordSubCatTab=option.currentMenu;
    }
  }
  updateBreadCrumb(option) {
    this.breadCrumbHandler.next(option);
  }
  openMapOverlay(option) {
    this.mapOverlayHandler.next(option);
  }
  showHttpErrorMsg() {
    this.showAlert({
      "type": "danger",
      "msg": "Oops! Something went wrong while getting data from server."
    })

  }
  openLogin() {
    if(this.checkAlreadyLoggedIn()){
    //   this.showAlert({
    //     type: "success", msg: 'Already logged in'
    // });
    this.router.navigate(['my']);
    }
    else{
      this.loginHandler.next();
    }
    
  }

  checkAlreadyLoggedIn(){
    const token=localStorage.getItem('access_token');
    return tokenNotExpired('access_token', token);
  }

  redirectToLogin(){
    this.router.navigate(['']);
    this.userName='LOGIN';
     
    this.showAlert({
      type: "danger", msg: "Please LogIn First"
    });
    setTimeout(()=>{
      this.openLogin();
    },1000);
  }
}