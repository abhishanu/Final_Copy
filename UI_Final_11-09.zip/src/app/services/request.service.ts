//Application level services 
import { Injectable } from '@angular/core';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import{CommonService } from './common.service';
import {JwtHelper} from 'angular2-jwt';
import {AuthHttp} from 'angular2-jwt';

@Injectable()
export class RequestService {
  headers:any;
  requestOptions:any;
  jwtHelper: JwtHelper = new JwtHelper();
  accessToken: string;

  baseServiceUrl :any= "http://172.16.19.149:8080/";
  baseImageServiceUrl :any= "https://s3.ap-south-1.amazonaws.com/images.religiousindia.com/";
  constructor(private _http:Http,private _commonService:CommonService,private http:AuthHttp){
    this.headers = new Headers({
      'Content-Type':'application/json'
    });
    this.requestOptions = new RequestOptions({headers:this.headers});
  }

  fetchData(serviceName){    
    return this._http.get(this.baseServiceUrl+serviceName);
  }

  postData(serviceName,params){    
    return this._http.post(this.baseServiceUrl+serviceName,params,this.requestOptions);
  }

  postAuthData(serviceName,params){
    return this.http.post(this.baseServiceUrl+serviceName,params,this.requestOptions);
  }
  
  authData(serviceName,params){
    const headers = new Headers();

    return this._http.post(this.baseServiceUrl+serviceName, params, {headers})
      .map(res => res.json())
      .map((res: any) => {
        if (res.response.accessToken) {
          return res.response.accessToken;
        }
        return null;
      });
  }

  
  logout() {
    this.accessToken = null;
    this._commonService.userName='Login';
    localStorage.removeItem('access_token');
  }

  login(accessToken: string) {
    //const decodedToken = this.jwtHelper.decodeToken(accessToken);
    //console.log(decodedToken);

   // this.isAdmin = decodedToken.authorities.some(el => el === 'ADMIN_USER');
    this.accessToken = accessToken;
    
    localStorage.setItem('access_token', accessToken);
  }

  fetchAuthData(serviceName){
    return this.http.get(this.baseServiceUrl+serviceName);
  }

  fbLogIn(accessUrl:any){
    return this._http.get(accessUrl);
  }
  
}