import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'curated-experiences',
  templateUrl: './curated-experiences.component.html',
})
export class CuratedExperiencesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
