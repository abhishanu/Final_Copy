import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { RequestService } from '../../services/request.service';
import { Router } from '@angular/router';

@Component({
  selector: 'forget-pwd',
  templateUrl: './forget-pwd.component.html'
})
export class ForgetPwd implements OnInit {
    email:String='';
    isForgetPwd:boolean;
    isOtpSend:boolean;
    isChangePwd:boolean;
    otp:String;
    params:any;
    paramsForChangePwd:any;
    cnfPwd:String;
    newPwd:String;
    accessKey:String;
    constructor(private router: Router,private _commonService: CommonService, private _requestService: RequestService){}

    ngOnInit(): void {
        this.isForgetPwd=true;
        this.isOtpSend=false;
        this.isChangePwd=false;
    }

    goToOTP(){
            if (this.email!=='') {
                this.isForgetPwd=false;
                 this.isOtpSend=true;
            } else {
                 this._commonService.showAlert({
            type: "danger", msg: "please enter OTP"});
            }
    }

    forgetPwd(){
        const reqParam='forgetPasswordOTP?user='+this.email;
  
    if(this.email!=null && this.email!=''){
      this._requestService.fetchData(reqParam).subscribe(
        data=>{
          const dataItem=data.json();
          
          if(dataItem.status == "ERROR"){
              this._commonService.showAlert({
            type: "danger", msg: dataItem.response});
          }
          else{
            this._commonService.showAlert({
              type: "success", msg: dataItem.response});

            this.goToOTP();
          }
        },err=>{
          
          this._commonService.showHttpErrorMsg();
        });
    }else{
      this._commonService.showAlert({
        type: "danger", msg: 'Please enter mail id'});
    }
}

    verifyOtp(){
        this.params = {
        "requestType": "verifyOTP",
        "requestParam": {
            "OTP": this.otp,
            "userId": this.email
      }
    }
        this._requestService.postData("verifyOTP",this.params).subscribe(
            data=>{
                const dataItem=data.json();

                if(dataItem.status==='OK'){
                    this._commonService.showAlert({
                        type: "success", msg: 'OTP matched'});
                        this.accessKey=dataItem.response.Access_Key;
                this.isOtpSend=false;
                this.isChangePwd=true;
                }
            },
            err=>{
                this._commonService.showHttpErrorMsg();
            }
        );
    }

    changePwd(){
            this.paramsForChangePwd = {
            "requestType": "forgetPwd",
            "requestParam": {
                "userId": this.email,
                "pwd": this.cnfPwd,
                "accessKey":this.accessKey
                }
            }
        this._requestService.postData("changeForgetPassword",this.paramsForChangePwd).subscribe(
            data=>{
                this._commonService.showAlert({
                        type: "success", msg: 'Password changed successfully'});
                this.router.navigate(['']);
            },
            err=>{
            this._commonService.showHttpErrorMsg();
            }
        );
    }
}